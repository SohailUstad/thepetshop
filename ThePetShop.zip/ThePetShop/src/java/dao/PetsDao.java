
package dao;

import entities.Pets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class PetsDao {
    private Connection con;

    public PetsDao(Connection con) {
        this.con = con;
    }
    
    public boolean savePet(Pets p){
        boolean f=false;
        
        try {
            String query="insert into pets(pName,pPhoto,pGender,pColour,pHeight,pWeight,pBreed,pPrice) values(?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt=this.con.prepareStatement(query);
            pstmt.setString(1, p.getpName());
            pstmt.setString(2, p.getpPhoto());
            pstmt.setString(3, p.getpGender());
            pstmt.setString(4, p.getpColour());
            pstmt.setString(5, p.getpHeight());
            pstmt.setString(6, p.getpWeight());
            pstmt.setString(7, p.getpBreed());
            pstmt.setString(8, p.getpPrice());
            pstmt.executeUpdate();
            f=true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return f;
    }
    
    public List<Pets> getAllPets(){
        List<Pets> l=new ArrayList<Pets>();
        
        try {
            String query="select * from pets";
            PreparedStatement pstmt=this.con.prepareStatement(query);
            ResultSet rs= pstmt.executeQuery();
            while(rs.next()){
                int pId=rs.getInt("pId");
                String pName = rs.getString("pName");
                String pPhoto = rs.getString("pPhoto");
                String pGender = rs.getString("pGender");
                String pColour = rs.getString("pColour");
                String pHeight = rs.getString("pHeight");
                String pWeight = rs.getString("pWeight");
                String pBreed = rs.getString("pBreed");
                String pPrice = rs.getString("pPrice");
                Pets p=new Pets(pId,pName,pPhoto,pGender,pColour,pHeight,pWeight,pBreed,pPrice);
                l.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return l;
    }
    
    public Pets getPetById(String id){
        Pets p=null;
        try {
            String query="select * from pets where pId=?";
            PreparedStatement pstmt=this.con.prepareStatement(query);
            pstmt.setString(1, id);
            ResultSet rs= pstmt.executeQuery();
            while(rs.next()){
                int pId=rs.getInt("pId");
                String pName = rs.getString("pName");
                String pPhoto = rs.getString("pPhoto");
                String pGender = rs.getString("pGender");
                String pColour = rs.getString("pColour");
                String pHeight = rs.getString("pHeight");
                String pWeight = rs.getString("pWeight");
                String pBreed = rs.getString("pBreed");
                String pPrice = rs.getString("pPrice");
                p=new Pets(pId,pName,pPhoto,pGender,pColour,pHeight,pWeight,pBreed,pPrice);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p;
    }
    
}
