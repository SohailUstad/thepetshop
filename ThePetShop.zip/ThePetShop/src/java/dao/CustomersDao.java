package dao;

import entities.Customers;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomersDao {

    private Connection con;

    public CustomersDao(Connection con) {
        this.con = con;
    }

    public boolean saveCustomer(Customers c) {
        boolean f = false;

        try {
            String query = "insert into customers(fullName , email , password , mobileNumber , pinCode) values(?,?,?,?,?)";
            PreparedStatement pstmt = this.con.prepareStatement(query);
            pstmt.setString(1, c.getFullName());
            pstmt.setString(2, c.getEmail());
            pstmt.setString(3, c.getPassword());
            pstmt.setString(4, c.getMobileNumber());
            pstmt.setString(5, c.getPinCode());
            pstmt.executeUpdate();
            f = true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return f;
    }

    public Customers getCustomerByEmailAndPassword(String email, String password) {
        Customers c = null;

        try {
            String query = "select * from customers where email=? and password=?";
            PreparedStatement pstmt = this.con.prepareStatement(query);
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                c = new Customers();
                c.setcId(rs.getInt("cId"));
                c.setFullName(rs.getString("fullName"));
                c.setEmail(rs.getString("email"));
                c.setPassword(rs.getString("password"));
                c.setMobileNumber(rs.getString("mobileNumber"));
                c.setPinCode(rs.getString("pinCode"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return c;
    }
}
