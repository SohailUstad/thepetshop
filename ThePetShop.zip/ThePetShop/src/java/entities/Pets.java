
package entities;

public class Pets {
    private int pId;
    private String pName,pPhoto,pGender,pColour,pHeight,pWeight,pBreed,pPrice;

    public Pets(int pId, String pName, String pPhoto, String pGender, String pColour, String pHeight, String pWeight, String pBreed, String pPrice) {
        this.pId = pId;
        this.pName = pName;
        this.pPhoto = pPhoto;
        this.pGender = pGender;
        this.pColour = pColour;
        this.pHeight = pHeight;
        this.pWeight = pWeight;
        this.pBreed = pBreed;
        this.pPrice = pPrice;
    }

    public Pets(String pName, String pPhoto, String pGender, String pColour, String pHeight, String pWeight, String pBreed, String pPrice) {
        this.pName = pName;
        this.pPhoto = pPhoto;
        this.pGender = pGender;
        this.pColour = pColour;
        this.pHeight = pHeight;
        this.pWeight = pWeight;
        this.pBreed = pBreed;
        this.pPrice = pPrice;
    }

    public Pets() {
    }

    public int getpId() {
        return pId;
    }

    public void setpId(int pId) {
        this.pId = pId;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public String getpPhoto() {
        return pPhoto;
    }

    public void setpPhoto(String pPhoto) {
        this.pPhoto = pPhoto;
    }

    public String getpGender() {
        return pGender;
    }

    public void setpGender(String pGender) {
        this.pGender = pGender;
    }

    public String getpColour() {
        return pColour;
    }

    public void setpColour(String pColour) {
        this.pColour = pColour;
    }

    public String getpHeight() {
        return pHeight;
    }

    public void setpHeight(String pHeight) {
        this.pHeight = pHeight;
    }

    public String getpWeight() {
        return pWeight;
    }

    public void setpWeight(String pWeight) {
        this.pWeight = pWeight;
    }

    public String getpBreed() {
        return pBreed;
    }

    public void setpBreed(String pBreed) {
        this.pBreed = pBreed;
    }

    public String getpPrice() {
        return pPrice;
    }

    public void setpPrice(String pPrice) {
        this.pPrice = pPrice;
    }
    
}
