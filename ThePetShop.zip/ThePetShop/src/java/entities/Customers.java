
package entities;


public class Customers {
    private int cId;
    private String fullName;
    private String email;
    private String password;
    private String mobileNumber;
    private String pinCode;

    public int getcId() {
        return cId;
    }

    public void setcId(int cId) {
        this.cId = cId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public Customers(int cId, String fullName, String email, String password, String mobileNumber, String pinCode) {
        this.cId = cId;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.mobileNumber = mobileNumber;
        this.pinCode = pinCode;
    }

    public Customers(String fullName, String email, String password, String mobileNumber, String pinCode) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.mobileNumber = mobileNumber;
        this.pinCode = pinCode;
    }

    public Customers() {
    }

    @Override
    public String toString() {
        return "Customers{" + "cId=" + cId + ", fullName=" + fullName + ", email=" + email + ", password=" + password + ", mobileNumber=" + mobileNumber + ", pinCode=" + pinCode + '}';
    }
    
    
}
